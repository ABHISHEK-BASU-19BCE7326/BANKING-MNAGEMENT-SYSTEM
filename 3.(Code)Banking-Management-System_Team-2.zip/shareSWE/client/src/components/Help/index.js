import React from 'react';
import ContactForm from './Form';

const Help = () => (
   <div className="row panel-content">
      <div className="col-sm-8 offset-sm-2 col-md-6 offset-md-3">
         <section className="module help">
            <h1>Do you need help?</h1>
            <p>
               We Reply within 24Hrs
            </p>
            <h2>Contact us</h2>
            <ContactForm />
         </section>
      </div>
   </div>
);

export default Help;
