import React from 'react';
import './style.scss';

const Backdrop = props => <div className="backdrop" />;

export default Backdrop;
