import React from 'react';
import SingleButton from 'components/UI/Buttons/SingleButton';

import './style.scss';

const HomeNewFeatures = () => (
   <div className="home-new-features-box">
      
   </div>
);

export default HomeNewFeatures;
