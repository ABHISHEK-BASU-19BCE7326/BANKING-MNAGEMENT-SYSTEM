import React from 'react';
import PropTypes from 'prop-types';

import './style.scss';

const HomeHeader = props => (
   <header className="home-header">
      <h1>Welcome to Banking Management System </h1>
      <h2>SWE Lab Team-2</h2>
   </header>
);

HomeHeader.propTypes = {
   clients: PropTypes.array,
   lastClient: PropTypes.object
};

export default HomeHeader;
