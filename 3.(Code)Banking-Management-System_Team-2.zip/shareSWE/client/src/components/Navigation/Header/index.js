import React from "react";
import { Link } from "react-router-dom";

import "./style.scss";

const NavigationHeader = (props) => {
  return (
    <header className="navigation-header">
      <div className="user-profile-box">
        <Link to="/panel/profile">
          <img
            style={{ height: "60px" }}
            src="https://www.seekpng.com/png/full/966-9665493_my-profile-icon-blank-profile-image-circle.png"
            alt="User profile"
          />
          <span>
            {props.user.firstName} {props.user.lastName}
          </span>
        </Link>
      </div>

      <ul className="navigation-header-links">
        <li>
          <Link to="/logout">Logout</Link>
        </li>
        <li className="toggle-menu">
          <button onClick={props.toggleMobileNav}>
            <i className="ion-navicon-round" />
          </button>
        </li>
      </ul>
    </header>
  );
};

export default NavigationHeader;
