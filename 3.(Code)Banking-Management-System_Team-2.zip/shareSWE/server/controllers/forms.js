// Utilities
const { throwError, passError, handleValidationErrors } = require('@util/errors');
const { checkUpdatesValid, applyUpdates } = require('@util/updates');


exports.sendHelpForm = async (req, res, next) => {
   res.status(200).json({ status: 'Form has been sent' });
};
